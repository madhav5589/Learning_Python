#
# Example file for working with timedelta objects
#

from datetime import date
from datetime import time
from datetime import datetime
from datetime import timedelta

# construct a basic timedelta and print it
now = datetime.now()
s = timedelta(days=365, hours=4, minutes=25)
print(s)

# print today's date
print("Today's date is: ", now.date())


# print today's date one year from now
print("Today's date one year from now will be: ", str(now.date() + timedelta(days=365)))


# create a timedelta that uses more than one argument


# calculate the date 1 week ago, formatted as a string


### How many days until April Fools' Day?


# use date comparison to see if April Fool's has already gone for this year
# if it has, use the replace() function to get the date for next year


# Now calculate the amount of time until April Fool's Day  


